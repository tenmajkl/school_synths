# Synthesizers

School project of listing synths.

## Compilation

```sh
make
```

## Paper

See [overleaf](https://www.overleaf.com/read/rzbdhmqgzdvn).
